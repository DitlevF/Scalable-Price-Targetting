README

We would kindly ask, that the files are run in the following sequence:

1. First Step_BLasso Probit Function.R
2. Second Step_Generate Data, Run WLB, Run BLasso, Run Probit, Calculate Profits and Elasticities.R
3. Third Step_Create Plots and Graphs.R
4. Fourth Step_Bayes Factor.R

